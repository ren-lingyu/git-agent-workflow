Declared reference file.
